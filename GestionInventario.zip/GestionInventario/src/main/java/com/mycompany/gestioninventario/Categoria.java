package com.mycompany.gestioninventario;

public class Categoria {

    private int codigoCategoria;
    private String nombreCategoria;

    public Categoria(int codigoCategoria, String nombreCategoria) {
        this.codigoCategoria = codigoCategoria;
        this.nombreCategoria = nombreCategoria;
    }

    public int getCodigoCategoria() {
        return codigoCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }
}
