package com.mycompany.gestioninventario;

public class Producto {

    private String nombreProducto;
    private double precioProducto;
    private int numeroReferencia;
    private int cantidadDisponible;
    private Categoria categoria;

    public Producto(String nombreProducto, double precioProducto, int numeroReferencia, int cantidadDisponible, Categoria categoria) {
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.numeroReferencia = numeroReferencia;
        this.cantidadDisponible = cantidadDisponible;
        this.categoria = categoria;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }

    public int getNumeroReferencia() {
        return numeroReferencia;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public Categoria getCategoria() {
        return categoria;
    }
}
