package com.mycompany.gestioninventario;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class GestionInventario {
    private Scanner scanner = new Scanner(System.in);
    private Map<Integer, Categoria> categorias = new HashMap<>();
    private Map<Integer, Producto> inventario = new HashMap<>();

    public static void main(String[] args) {
        GestionInventario gestionInventario = new GestionInventario();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            gestionInventario.mostrarMenu();
            int opcion = scanner.nextInt();
            gestionInventario.ejecutarOpcion(opcion);
        }
    }

    public GestionInventario() {
        // Inicializar las categorías
        categorias.put(1, new Categoria(1, "Computadores"));
        categorias.put(2, new Categoria(2, "Celulares"));
        categorias.put(3, new Categoria(3, "Electrodomésticos"));
        categorias.put(4, new Categoria(4, "TV"));
        categorias.put(5, new Categoria(5, "Accesorios"));
        categorias.put(6, new Categoria(6, "Videojuegos"));
        categorias.put(7, new Categoria(7, "Audio y video"));
    }

    public void mostrarMenu() {
        System.out.println("***** Menú *****");
        System.out.println("1. Agregar Categoría");
        System.out.println("2. Eliminar Categoría");
        System.out.println("3. Agregar Producto");
        System.out.println("4. Eliminar Producto");
        System.out.println("5. Mostrar Inventario por Categoría");
        System.out.println("6. Mostrar Categorías");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }

    public void ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 1:
                agregarCategoria();
                break;
            case 2:
                eliminarCategoria();
                break;
            case 3:
                agregarProducto();
                break;
            case 4:
                eliminarProducto();
                break;
            case 5:
                mostrarInventarioPorCategoria();
                break;
            case 6:
                mostrarCategorias();
                break;
            case 0:
                System.out.println("¡Hasta luego!");
                System.exit(0);
                break;
            default:
                System.out.println("Opción no válida. Inténtelo de nuevo.");
        }
    }

    public void agregarCategoria() {
        System.out.print("Ingrese el código de la nueva categoría: ");
        int codigoCategoria = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Ingrese el nombre de la nueva categoría: ");
        String nombreCategoria = scanner.nextLine();

        Categoria nuevaCategoria = new Categoria(codigoCategoria, nombreCategoria);

        if (!categorias.containsKey(codigoCategoria)) {
            categorias.put(codigoCategoria, nuevaCategoria);
            System.out.println("Categoría agregada con éxito.");
        } else {
            System.out.println("Error: La categoría ya existe.");
        }
    }

    public void eliminarCategoria() {
        System.out.print("Ingrese el código de la categoría a eliminar: ");
        int codigoCategoria = scanner.nextInt();

        if (categorias.containsKey(codigoCategoria)) {
            categorias.remove(codigoCategoria);
            System.out.println("Categoría eliminada con éxito.");
        } else {
            System.out.println("Error: La categoría no existe.");
        }
    }

    public void agregarProducto() {
        System.out.print("Ingrese el nombre del nuevo producto: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el precio del nuevo producto: ");
        double precio = scanner.nextDouble();
        System.out.print("Ingrese el número de referencia del nuevo producto: ");
        int numeroReferencia = scanner.nextInt();
        System.out.print("Ingrese la cantidad disponible del nuevo producto: ");
        int cantidadDisponible = scanner.nextInt();

        System.out.println("Categorías disponibles:");
        mostrarCategorias();
        System.out.print("Seleccione el código de la categoría del nuevo producto: ");
        int codigoCategoria = scanner.nextInt();

        Categoria categoria = categorias.get(codigoCategoria);

        Producto nuevoProducto = new Producto(nombre, precio, numeroReferencia, cantidadDisponible, categoria);

        if (!inventario.containsKey(numeroReferencia)) {
            inventario.put(numeroReferencia, nuevoProducto);
            System.out.println("Producto agregado con éxito.");
        } else {
            System.out.println("Error: Ya existe un producto con el mismo número de referencia.");
        }
    }

    public void eliminarProducto() {
        System.out.print("Ingrese el número de referencia del producto a eliminar: ");
        int numeroReferencia = scanner.nextInt();

        if (inventario.containsKey(numeroReferencia)) {
            inventario.remove(numeroReferencia);
            System.out.println("Producto eliminado con éxito.");
        } else {
            System.out.println("Error: El producto no existe.");
        }
    }

    public void mostrarInventarioPorCategoria() {
        System.out.println("Categorías disponibles:");
        mostrarCategorias();
        System.out.print("Seleccione el código de la categoría para mostrar el inventario: ");
        int codigoCategoria = scanner.nextInt();

        System.out.println("Inventario de la categoría: " + categorias.get(codigoCategoria).getNombreCategoria());
        for (Producto producto : inventario.values()) {
            if (producto.getCategoria().getCodigoCategoria() == codigoCategoria) {
                System.out.println("Nombre: " + producto.getNombreProducto() + ", Precio: " + producto.getPrecioProducto() +
                        ", Cantidad Disponible: " + producto.getCantidadDisponible());
            }
        }
    }

    public void mostrarCategorias() {
        for (Categoria categoria : categorias.values()) {
            System.out.println(categoria.getCodigoCategoria() + " - " + categoria.getNombreCategoria());
        }
    }


}

